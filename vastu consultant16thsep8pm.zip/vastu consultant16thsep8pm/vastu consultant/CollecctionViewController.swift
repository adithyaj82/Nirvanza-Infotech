//
//  ViewController.swift
//  CollectionViewBlog
//
//  Created by Erica Millado on 7/3/17.
//  Copyright © 2017 Erica Millado. All rights reserved.
//

import UIKit

class CollecctionViewController: UIViewController, UICollectionViewDataSource,UICollectionViewDelegate {
    
    @IBOutlet var collectionView: UICollectionView!
    var ff = ["About Us","Services","Astrology","Vastu","Kundli","Gallery","Share","Enquiry","Contact Us"]

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
 
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ff.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewCell", for: indexPath) as! CollectionViewCell
        cell.bookLabel.text = ff[indexPath.row]
        cell.bookImage.image = UIImage(named:  ff[indexPath.row])
       
//        let rowIndex = indexPath.row
//        print("row index = \(rowIndex)")
//        
//        if rowIndex == 6{
//            cell.backgroundColor = UIColor.orange
//        }

        return cell
        
    }
     func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
       // cell?.layer.borderWidth = 2.0
        //cell?.layer.borderColor = UIColor.gray.cgColor
        let iPath = self.collectionView.indexPathsForSelectedItems
        let indexPath : NSIndexPath = iPath![0] as NSIndexPath
        let rowIndex = indexPath.row
        print("row index = \(rowIndex)")
        
        if rowIndex == 0{
            print("one !")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutViewController")as! AboutViewController
            self.navigationController?.pushViewController(vc, animated: true)


        }
        if rowIndex == 1{
            print("two !")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesViewController")as! ServicesViewController
            self.navigationController?.pushViewController(vc, animated: true)

            
        }
        if rowIndex == 2{
            print("three !")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AstrologyViewController")as! AstrologyViewController
            self.navigationController?.pushViewController(vc, animated: true)

            
        }
        if rowIndex == 3{
            print("four !")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VastuViewController")as! VastuViewController
            self.navigationController?.pushViewController(vc, animated: true)

        }
        if rowIndex == 4{
            print("five !")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "KundliViewController")as! KundliViewController
            self.navigationController?.pushViewController(vc, animated: true)

        }
        if rowIndex == 5{
            print("six !")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "GalleryViewController")as! GalleryViewController
            self.navigationController?.pushViewController(vc, animated: true)

        }
        if rowIndex == 6{
            print("seven !")
            let activityVC = UIActivityViewController(activityItems: ["https://play.google.com/store/apps/details?id=com.nirvanza.vastuconsultant"], applicationActivities: nil)
            activityVC.popoverPresentationController?.sourceView = self.view
            self.present(activityVC, animated: true, completion: nil)
            
        }
        if rowIndex == 7{
            print("eight !")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "EnquiryViewController")as! EnquiryViewController
            self.navigationController?.pushViewController(vc, animated: true)

        }
        if rowIndex == 8{
            print("nine !")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ContactViewController")as! ContactViewController
            self.navigationController?.pushViewController(vc, animated: true)

        }
      
    }
}

