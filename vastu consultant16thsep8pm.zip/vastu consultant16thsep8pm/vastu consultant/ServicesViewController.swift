//
//  ServicesViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class ServicesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    @IBAction func Astrology(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/astrology.html";
    self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func faceReading(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/facereading.html";
 self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func palmreading(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/palmreading.html";

        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func kundi(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/kundali.html";

        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func Astrological(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/astrologicalremedies.html";

        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func hawan(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/hawanpuja.html";

        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func Astro(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/astroconsultant.html";

        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func DoshaNirvan(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/doshanivaran.html";

        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func Yantras(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/yantras.html";

        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func Rudraksha(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/rudraksha.html";

        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func web(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController")as! WebViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}
