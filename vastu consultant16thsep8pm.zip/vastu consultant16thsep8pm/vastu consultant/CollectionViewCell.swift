//
//  CollectionViewCell.swift
//  vastu consultant
//
//  Created by adithya on 9/15/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var bookLabel: UILabel!
  
    @IBOutlet var bookImage: UIImageView!
    
    
    
    
    
    
    
    
}
