//
//  ViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//    @IBAction func show(_ sender: Any) {
//           self.slow()
//
//    }
    @IBAction func ss(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CollecctionViewController")as! CollecctionViewController
        self.navigationController?.pushViewController(vc, animated: true)

    }
    
    @IBOutlet weak var image: UIImageView!
    override func viewWillAppear(_ animated: Bool) {
       


    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//
      
        image?.center = view.center
        
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(4.0)
        UIView.setAnimationDelegate(self)
        
        UIView.animate(withDuration: 3, delay: 0, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.image.alpha = 1.0
            self.image.transform = CGAffineTransform(rotationAngle: (180.0 * .pi) / 180.0)
    
        }, completion: nil)
        
        
        UIView.commitAnimations()
        

        
            
      

    
    }
//    override func viewDidAppear(_ animated: Bool) {
//        UIView.animate(withDuration: 13, delay: 5, options: UIViewAnimationOptions.curveEaseIn, animations: {
//            self.image.alpha = 0.0
//
//         //   self.slow()
//
//
//
//
//        }, completion: nil)

  //  }
//    func slow(){
//        
//        UIView.animate(withDuration: 300, delay: 500, options: UIViewAnimationOptions.curveEaseIn, animations: {
//
////              let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController")as! HomeViewController
////            self.navigationController?.pushViewController(vc, animated: true)
//
//
//        }, completion: nil)
//
//        }
//        
    
  

}

