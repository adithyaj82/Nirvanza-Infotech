//
//  ContactViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit
import MapKit

class ContactViewController: UIViewController,MKMapViewDelegate {
    var pin:AnnotationPin!
    @IBOutlet weak var menuButton: UIBarButtonItem!

    @IBOutlet weak var mapView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()

        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
        mapView.delegate = self

        let coordinate = CLLocationCoordinate2D(latitude: 23.032209, longitude: 72.568625)
        let region = MKCoordinateRegionMakeWithDistance(coordinate, 1000, 1000)
        
        mapView.setRegion(region, animated: true)
        
        pin = AnnotationPin(title: "Ankur Institute Of Child Health", Subtitle: "Behind City Gold Cinema, Ashram Road, Mill Officer's Colony, Muslim Society, Navrangpura, Mill Officer's Colony, Muslim Society, Navrangpura, Ahmedabad, Gujarat 380009", coordinate: coordinate)
        mapView.addAnnotation(pin)
    }
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let annotationView = MKAnnotationView(annotation: pin, reuseIdentifier: "tajPin")
        annotationView.image = UIImage(named:"location.png")
        let transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        annotationView.transform = transform
        return annotationView
    }
   

}
