//
//  ServicesTableViewCell.swift
//  Ankur app
//
//  Created by adithya on 9/8/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesTableViewCell: UITableViewCell {
    
    @IBOutlet var borderLayer: UIView!
    @IBOutlet var doctorList: UILabel!
    @IBOutlet var imageviewss: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
