//
//  ServicesViewController.swift
//  Ankur app
//
//  Created by adithya on 9/8/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet var menuButton: UIBarButtonItem!
    let doctorEdu = ["Obstetrics","Gynaecology","Sonography","Infertility","Operations","Pre-Conceptional Counselling","Garbh Sanskar"]
    let doctorsList = ["Obstetrics","Gynaecology","Sonography","Infertility","Operations","Pre-Conceptional Counselling","Garbh Sanskar"]
    let doctorImages = ["facilityfour.jpg","gynaeco.jpg","facilityfive.jpg","infertility.jpg","hqdefault.jpg","facilitysix.jpg","garbh.jpg"]
    
    let doctordata = ["Obstetrics and Gynaecology @ Queen Hospital\n\nAt Queen Hospital Ahmedabad, we believe that preventive health care begins with the care of healthy.\n\nWe have programs in both Gynaecology and Obstetrics for the prevention and early detection of different kind of disorders. Queen Hospital of Obstetrics and Gynaecology provides you superior maternity and reproductive health care benefits and services with the help of well experience gynaecologists and radiologists.\nAt our hospital women check-up designed to diagnose earlier symptoms of gynaecological diseases.\n\nWe have well experienced specialist team in providing a wide range of services for Obstetrics and Gynaecology.\n\nFrom pre-pregnancy care to childbearing and post-menopausal care, there is a solution for all health concerns a woman experiences during these stages. You will have access to:\n\n• Highly experienced and compassionate obstetricians.\n• Extraordinary nursing care.\n• Gynaecologist.\n• Intensive care for newborns.\n• Maternity facilities.\n\nThe prime objective of our hospital is to promote health of women by offering complete care, support as well as empathy that they require.\n\nThe branch of Obstetrics and Gynaecology addresses the needs of ladies from their adolescent years through pregnancy to menopause and the past, with qualified pros, extraordinarily prepared medical with qualified specialists, specially trained nurses and the latest equipment to deal with Obstetric emergencies, high risk pregnancies and premature babies.","Obstetrics and Gynaecology @ Queen Hospital\n\nAt Queen Hospital Ahmedabad, we believe that preventive health care begins with the care of healthy.\n\nWe have programs in both Gynaecology and Obstetrics for the prevention and early detection of different kind of disorders. Queen Hospital of Obstetrics and Gynaecology provides you superior maternity and reproductive health care benefits and services with the help of well experience gynaecologists and radiologists.\nAt our hospital women check-up designed to diagnose earlier symptoms of gynaecological diseases.\n\nWe have well experienced specialist team in providing a wide range of services for Obstetrics and Gynaecology.\n\nFrom pre-pregnancy care to childbearing and post-menopausal care, there is a solution for all health concerns a woman experiences during these stages. You will have access to:\n\n• Highly experienced and compassionate obstetricians.\n• Extraordinary nursing care.\n• Gynaecologist.\n• Intensive care for newborns.\n• Maternity facilities.\n\nThe prime objective of our hospital is to promote health of women by offering complete care, support as well as empathy that they require.\n\nThe branch of Obstetrics and Gynaecology addresses the needs of ladies from their adolescent years through pregnancy to menopause and the past, with qualified pros, extraordinarily prepared medical with qualified specialists, specially trained nurses and the latest equipment to deal with Obstetric emergencies, high risk pregnancies and premature babies.","Est Significance: Sonography is an ultrasound based diagnostic imaging technique used to visualize subcutaneous body structures including tendons, muscles, joints, vessels and internal organs.Sonography 300 Ultrasounds are commonly used to detect or aid in the detection of abnormalities and conditions related to pregnancy. Ultrasounds are usually combined with other tests, such as dual marker, triple marker tests, to validate a diagnosis.List of Sonography tests conducted at  QUEEN HOSPITAL\n\n• Obstetric\n• 2D /3D Sonography\n• Color Doppler\n• Anomaly Scan\n• Gynecological sonography\n• Sonography for infertility workout\n• Ovulation Study","Infertility means not being able to become pregnant after a year of trying. If a woman can get pregnant but keeps having miscarriages or stillbirths, that’s also called infertility.\n\nInfertility is fairly common. After one year of having unprotected sex, about 15 percent of couples are unable to get pregnant. About a third of the time, infertility can be traced to the woman. In another third of cases, it is because of the man. The rest of the time, it is because of both partners or no cause can be found.\n\nThere are treatments that are specifically for men or for women. Some involve both partners. Drugs, assisted reproductive technology, and surgery are common treatments. Happily, many couples treated for infertility go on to have babies.\n\nWe take enough care for each aspects like:\n– Infertility Investigations\n– Diagnostic Laparoscopy\n-D & C\n– Intra – uterine Iusemunation (IUI)\n-Recurrent miscarriage","Following type of Operations are carried out at Queen Hospital with all the latest infrastructure and more than caring staff which are always here to help our patients\n\nMajor:\n– Lscs (lower segment caesarean section)\n– Abdominal Hysterectomy\n– Vaginal Hysterectomy\n– Total Laparoscopic Hysterectomy (TLH)\n– Laparotomy & Laparoscopy for ectopic pregnancy\n– Various ovarian tumour excisions\n– Vaginoplasty\n\nMinor :\n– Cervical Encirclage\n– Dilatation & Currattage\n– Diagnostic Laproscopy and Hysteroscopy\n– Perineorrhaphy","Preconception care is a broad term that refers to the process of identifying social, behavioral, environmental, and biomedical risks to a woman’s fertility and pregnancy outcome and then reducing these risks through education, counseling, and appropriate intervention, when possible, before conception\nCaring for your health before you become pregnant is good for you and your baby.\nIt’s called preconception care. The goal is to check for any potential risks to you and your baby during pregnancy — and to address any medical issues you may have before you get pregnant.\nIt’s about becoming your healthiest self — physically and emotionally — before you take that next step into pregnancy.\nYou can get started by making a preconception counseling appointment with your health care provider. Here’s what to expect.\nWhat Happens at a Preconception Doctor’s Appointment?\nA preconception appointment is the perfect time to ask your doctor all the things that are on your mind — whether it’s your diet, prenatal vitamins, or any health concerns that run in your family.\nDuring a preconception office visit, you and your doctor will discuss your:\nReproductive history: This includes any previous pregnancies, your menstrual history, contraceptive use, previous Pap test results, and any sexually transmitted diseases or vaginal infections you’ve had in the past.\nMedical history: This includes any health problems you have now, so you can get those under control before you get pregnant.\nSurgical history: Have you had any surgeries, transfusions, and hospitalizations? If so, tell your doctor. It is especially important to inform your doctor of any gynecologic surgeries you may have had, including surgeries for fibroids or abnormal pap smears. A history of previous gynecologic surgeries may affect how you are managed during your pregnancy.\nCurrent medications: Tell your doctor about any prescription or over-the-counter medications you are taking or have taken. In some cases, it may be time to make a change to help prevent birth defects. Also tell your doctor about any herbal medicines or supplements you take.\nFamily health history: Tell your doctor about any medical conditions that run in your family, such as diabetes, hypertension, or history of blood clots.\nHome and workplace environment: You’ll talk about possible hazards — such as exposure to cat feces, X-rays, and lead or solvents — that could affect your ability to become pregnant or maintain a healthy pregnancy.\nYour weight: It’s a good idea to reach your ideal body weight before you get pregnant. This means losing weight if you are overweight to reduce your risk of complications during pregnancy; or gaining weight if you are underweight to reduce the risk of delivering a low birth-weight baby.\nLifestyle factors:\nYour doctor will ask you questions about you and your partner’s habits that could influence your pregnancy, such as smoking, drinking alcohol, and using recreational drugs. The goal is to help you stop any habits that could stand in the way of a healthy pregnancy. Your doctor will keep it confidential, so feel free to be open.\nExercise: Tell your doctor what type of exercise you do — and if you don’t work out, tell them that, too. Generally, you may continue your normal exercise routine while pregnant unless you are instructed to decrease or modify your activities.\nDiet: Your doctor will ask you about what you eat and drink. It’s ideal to go into pregnancy with good dietary habits already in place. That includes eating a variety of foods rich in fiber, and getting enough calcium, folic acid, and other nutrients.\nCaffeine: Before you get pregnant, your doctor may recommend limiting caffeine to no more than 300 milligrams (mg) per day. That’s about the amount in two 8-ounce cups of coffee. Remember, caffeine isn’t just in coffee and tea — it’s also in chocolate, some soft drinks, and certain medications.\nPrenatal vitamins: Before you’re pregnant, you should be taking a folic acid supplement. Folic acid makes it less likely that your baby will have a neural tube defect, and it’s best to start taking it before you conceive.\nYour doctor will likely recommend taking 400 micrograms (mcg) of folic acid daily before conception and in early pregnancy.\nDoctor may also:\nDo a physical exam to evaluate your heart, lungs, breasts, thyroid, and abdomen. A pelvic exam and Pap smear may also be performed.\nOrder lab tests: Some of the conditions screened for include rubella, hepatitis, HIV, syphilis, and others as indicated.\nDiscuss how to chart menstrual cycles to help detect ovulation and determine the time when you are most likely to get pregnant.\nCheck on your vaccinations: If you are not protected against rubella or chickenpox, your doctor may recommend the appropriate vaccines and delaying attempts to conceive for at least one month.\nDiscuss genetic counselling: Genetic counselling can help you understand your chance of having a child with a birth defect. It may be advised for older mothers and people with a family history of genetic problems, birth defects, or mental retardation.","A Very Unique service, you will find nowhere in Ahmedabad.\n\nGarbhasanskar is a Sanskrit term, which literally means ‘education in the womb’. It is traditionally believed that a child’s mental and behavioral development starts as soon as she is conceived. His personality begins to take shape in the womb, and this can be influenced by the mother’s state of mind during pregnancy. This knowledge can be traced back to ancient scriptures and is included in the Vedas.\n\nAccording to Garbhasanskar, your baby is able to sense and respond to outside influences like music and other sounds as well as your thoughts and feelings. That is why well-meaning elders in the family, talk about the importance of staying positive and relaxed during pregnancy.\n\nHow does Garbhasanskar work?\nTo help a mother remain in the best possible frame of mind in the interest of her growing baby, Garbhasanskar suggests a set of practices and way of life.\n\nThis includes reading or seeing things that make you happy, communicating with your baby, performing spiritual activities like pujas, meditating and eating healthily.\n\nYou may have seen a pregnant mother caressing or talking to her baby bump and perhaps even found it strange. She may well be practicing Garbhasanskar.\n\nWe Organize a seminar once in 2-3 months for pregnant woman at our hospital"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return doctorsList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! ServicesTableViewCell
        cell.doctorList.text = doctorsList[indexPath.row]
        // cell.imageviewss.image = UIImage(named: doctorImages[indexPath.row])
        
        cell.borderLayer.layer.cornerRadius = 15
        cell.borderLayer.layer.masksToBounds = false
       // cell.borderLayer.layer.borderColor = UIColor(displayP3Red: 0, green: 160, blue: 165, alpha: 1) as! CGColor
       // cell.borderLayer.layer.borderWidth = 2
        cell.borderLayer.layer.shadowOpacity = 0.78
        cell.borderLayer.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.borderLayer.layer.shadowRadius = 7
//        cell.borderLayer.layer.shadowColor = UIColor(displayP3Red: 0, green: 160, blue: 165, alpha: 1) as! CGColor
        cell.borderLayer.layer.masksToBounds = false
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vmim = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetail")as! ServicesDetailViewController
        vmim.str4 =  doctorEdu[indexPath.row]
        vmim.str5 =  doctorImages[indexPath.row]
        vmim.str6 =  doctordata[indexPath.row]
  self.navigationController?.pushViewController(vmim, animated: true)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 167/255, green: 55/255, blue: 140/255, alpha: 1)
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    
}
