//
//  showupdateViewController.swift
//  Queen Women Hospital
//
//  Created by adithya on 9/15/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class showupdateViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UITextViewDelegate {
    
    let arraaa2 = ["Obstetrics","Welcome to our hospital","Happy Womens Day",""]
    let arraaa = ["Queens Obstetrics Services is committed to providing top-quality care that is tai-lored to the individual needs and wishes of each patient.Our team including obstetricians,perinatologists and nurse midwives - has the expertise and compassion to care for the routine to the very highest-risk pregnancies and deliveries.","A Queen's Hospital,mulidisciplinary team of experience clinicians and specialist ensure that all patients needs are addressed,offering our patients and their families with the support they need during their period of illness as well as recovery.Our departmentstrives to provide our patients with the best care by keeping abreast of the fast changing panorama of women's health.The dapartment of obstetrics and gynrcology at queen's hospital implement the most advances technologies with new ans modern equipment,a leading medical team and unprecedented hospitalization conditions.","Internation Women's Day.Share some thought kept.A long term focus,control your anxiety and play on your strenghs-Ameera Shah Women needto get out of their comfort zone and venture into new areas of interest.It is time to be boldand takeon Non traditional roles.Geetha Kannan","Free Vedic Garbha sanskar is held at the queen hospital\nDate:18.03.2018\nTime:9 am onwards"]
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arraaa.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "updatecell", for: indexPath)as! UpdateCollectionViewCell
        cell.llb.text = arraaa2[indexPath.row]
        cell.txtvw.text = arraaa[indexPath.row]

        return cell
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool
    {
        if text == "\n"{
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }
    
    
    
    
}

