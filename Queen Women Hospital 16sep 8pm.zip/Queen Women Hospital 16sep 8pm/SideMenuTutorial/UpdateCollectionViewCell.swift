//
//  UpdateCollectionViewCell.swift
//  Queen Women Hospital
//
//  Created by adithya on 9/15/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class UpdateCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var llb: UILabel!
    @IBOutlet var txtvw: UITextView!
}
